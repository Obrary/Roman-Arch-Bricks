Product: Roman Arch Bricks, September 2014

Designer: Zombie Cat, http://zombie-cat.org/

Support:  http://forums.obrary.com/category/designs/roman-arch-bricks

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
Here's a teaching tool that shows students how blocks were shaped to make Roman arches.  The bricks are made from 3mm cardboard. It is sized to make the largest possible brick on a 18" x 24" laser bed.  If you print nine of these, you can make a roman arch.